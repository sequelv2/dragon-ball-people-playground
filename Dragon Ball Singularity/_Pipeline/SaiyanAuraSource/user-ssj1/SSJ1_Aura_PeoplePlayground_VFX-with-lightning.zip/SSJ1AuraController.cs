using UnityEngine;

namespace PeoplePlayground.VFX
{
    public enum SSJForm
    {
        SSJ1 = 1,
        SSJ2 = 2,
        SSJ3 = 3
    }

    /// <summary>
    /// Контроллер ауры SSJ1 и био-молний SSJ2/SSJ3 (60 FPS) для PersonBehaviour в People Playground.
    /// Управляет основным слоем пламени (SSJ1Aura.shader) и слоем дуговых разрядов (SSJLightningVFX.shader).
    /// </summary>
    public class SSJ1AuraController : MonoBehaviour
    {
        [Header("Target Ragdoll & Transformation")]
        public PersonBehaviour Person;
        public SSJForm CurrentForm = SSJForm.SSJ2;

        [Header("Materials")]
        public Material AuraMaterial;
        public Material LightningMaterial;

        [Header("Aura Quad Bounds")]
        public Vector2 QuadSize = new Vector2(2.6f, 3.8f);
        public Vector2 VerticalOffset = new Vector2(0f, 0.25f);

        private GameObject _auraQuadObj;
        private GameObject _lightningQuadObj;
        private MeshRenderer _auraRenderer;
        private MeshRenderer _lightningRenderer;
        private MaterialPropertyBlock _auraPropBlock;
        private MaterialPropertyBlock _boltPropBlock;

        private readonly Vector4[] _limbCapsules = new Vector4[10];
        private readonly float[] _limbRadii = new float[10];

        private static readonly int LimbCapsulesId = Shader.PropertyToID("_LimbCapsules");
        private static readonly int LimbRadiiId = Shader.PropertyToID("_LimbRadii");
        private static readonly int UseLimbCapsulesId = Shader.PropertyToID("_UseLimbCapsules");
        private static readonly int SSJLevelId = Shader.PropertyToID("_SSJLevel");
        private static readonly int AuraWidthId = Shader.PropertyToID("_AuraWidth");
        private static readonly int TurbulenceId = Shader.PropertyToID("_Turbulence");

        private void Awake()
        {
            _auraPropBlock = new MaterialPropertyBlock();
            _boltPropBlock = new MaterialPropertyBlock();
            CreateVFXQuads();
        }

        private void CreateVFXQuads()
        {
            // 1. Базовый слой пламенной ауры (за рэгдоллом)
            _auraQuadObj = GameObject.CreatePrimitive(PrimitiveType.Quad);
            _auraQuadObj.name = "SSJ_Aura_Base_Quad";
            Destroy(_auraQuadObj.GetComponent<Collider>());
            _auraQuadObj.transform.SetParent(transform, false);
            _auraQuadObj.transform.localScale = new Vector3(QuadSize.x, QuadSize.y, 1f);

            _auraRenderer = _auraQuadObj.GetComponent<MeshRenderer>();
            _auraRenderer.sharedMaterial = AuraMaterial;
            _auraRenderer.sortingLayerName = "Background";
            _auraRenderer.sortingOrder = -5;

            // 2. Поверхностный слой био-молний SSJ2 / SSJ3 (поверх ауры и конечностей)
            _lightningQuadObj = GameObject.CreatePrimitive(PrimitiveType.Quad);
            _lightningQuadObj.name = "SSJ2_3_Lightning_VFX_Quad";
            Destroy(_lightningQuadObj.GetComponent<Collider>());
            _lightningQuadObj.transform.SetParent(transform, false);
            _lightningQuadObj.transform.localScale = new Vector3(QuadSize.x, QuadSize.y, 1f);

            _lightningRenderer = _lightningQuadObj.GetComponent<MeshRenderer>();
            _lightningRenderer.sharedMaterial = LightningMaterial;
            _lightningRenderer.sortingLayerName = "Foreground";
            _lightningRenderer.sortingOrder = 10;
        }

        private void LateUpdate()
        {
            if (Person == null || Person.Limbs == null || Person.Limbs.Length == 0 || _auraRenderer == null)
                return;

            Transform rootLimb = Person.Limbs[0].transform;
            Vector3 centerPos = rootLimb.position + (Vector3)VerticalOffset;

            _auraQuadObj.transform.position = new Vector3(centerPos.x, centerPos.y, 0.05f);
            _auraQuadObj.transform.rotation = Quaternion.identity;

            _lightningQuadObj.transform.position = new Vector3(centerPos.x, centerPos.y, -0.05f);
            _lightningQuadObj.transform.rotation = Quaternion.identity;

            int count = Mathf.Min(Person.Limbs.Length, 10);
            for (int i = 0; i < count; i++)
            {
                LimbBehaviour limb = Person.Limbs[i];
                if (limb == null || limb.Collider == null) continue;

                Bounds b = limb.Collider.bounds;
                Vector3 up = limb.transform.up * (b.extents.y * 0.75f);
                Vector2 startUV = WorldToQuadUV(limb.transform.position - up, centerPos);
                Vector2 endUV = WorldToQuadUV(limb.transform.position + up, centerPos);

                _limbCapsules[i] = new Vector4(startUV.x, startUV.y, endUV.x, endUV.y);
                _limbRadii[i] = Mathf.Clamp(b.extents.x / QuadSize.x, 0.025f, 0.09f);
            }

            // Обновляем параметры ауры в зависимости от формы (SSJ1 / SSJ2 / SSJ3)
            _auraRenderer.GetPropertyBlock(_auraPropBlock);
            _auraPropBlock.SetInt(UseLimbCapsulesId, 1);
            _auraPropBlock.SetVectorArray(LimbCapsulesId, _limbCapsules);
            _auraPropBlock.SetFloatArray(LimbRadiiId, _limbRadii);
            _auraPropBlock.SetFloat(AuraWidthId, CurrentForm == SSJForm.SSJ3 ? 0.38f : (CurrentForm == SSJForm.SSJ2 ? 0.32f : 0.28f));
            _auraPropBlock.SetFloat(TurbulenceId, CurrentForm == SSJForm.SSJ1 ? 2.1f : 2.9f);
            _auraRenderer.SetPropertyBlock(_auraPropBlock);

            // Включаем молнии для SSJ2 и SSJ3
            bool showLightning = CurrentForm >= SSJForm.SSJ2 && LightningMaterial != null;
            _lightningQuadObj.SetActive(showLightning);
            if (showLightning)
            {
                _lightningRenderer.GetPropertyBlock(_boltPropBlock);
                _boltPropBlock.SetFloat(SSJLevelId, (float)CurrentForm);
                _boltPropBlock.SetVectorArray(LimbCapsulesId, _limbCapsules);
                _boltPropBlock.SetFloatArray(LimbRadiiId, _limbRadii);
                _lightningRenderer.SetPropertyBlock(_boltPropBlock);
            }
        }

        private Vector2 WorldToQuadUV(Vector3 worldPos, Vector3 quadCenter)
        {
            float u = (worldPos.x - quadCenter.x) / QuadSize.x + 0.5f;
            float v = (worldPos.y - quadCenter.y) / QuadSize.y + 0.5f;
            return new Vector2(u, v);
        }

        private void OnDestroy()
        {
            if (_auraQuadObj != null) Destroy(_auraQuadObj);
            if (_lightningQuadObj != null) Destroy(_lightningQuadObj);
        }
    }
}
