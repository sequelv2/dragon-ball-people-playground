using UnityEngine;

namespace PeoplePlayground.VFX
{
    /// <summary>
    /// Привязывает 60 FPS шейдер SSJ1Aura к рэгдоллу PersonBehaviour в People Playground.
    /// Передаёт координаты конечностей (LimbBehaviour) в шейдер для бесшовного слияния ауры вокруг всего тела.
    /// </summary>
    public class SSJ1AuraController : MonoBehaviour
    {
        [Header("Target Ragdoll")]
        public PersonBehaviour Person;
        public Material AuraMaterial;

        [Header("Aura Quad Bounds")]
        public Vector2 QuadSize = new Vector2(2.6f, 3.8f);
        public Vector2 VerticalOffset = new Vector2(0f, 0.25f);

        private GameObject _auraQuadObj;
        private MeshRenderer _quadRenderer;
        private MaterialPropertyBlock _propBlock;

        private readonly Vector4[] _limbCapsules = new Vector4[10];
        private readonly float[] _limbRadii = new float[10];

        private static readonly int LimbCapsulesId = Shader.PropertyToID("_LimbCapsules");
        private static readonly int LimbRadiiId = Shader.PropertyToID("_LimbRadii");
        private static readonly int UseLimbCapsulesId = Shader.PropertyToID("_UseLimbCapsules");

        private void Awake()
        {
            _propBlock = new MaterialPropertyBlock();
            CreateAuraQuad();
        }

        private void CreateAuraQuad()
        {
            _auraQuadObj = GameObject.CreatePrimitive(PrimitiveType.Quad);
            _auraQuadObj.name = "SSJ1_Aura_VFX_Quad";
            Destroy(_auraQuadObj.GetComponent<Collider>());

            _auraQuadObj.transform.SetParent(transform, false);
            _auraQuadObj.transform.localScale = new Vector3(QuadSize.x, QuadSize.y, 1f);

            _quadRenderer = _auraQuadObj.GetComponent<MeshRenderer>();
            _quadRenderer.sharedMaterial = AuraMaterial;
            _quadRenderer.sortingLayerName = "Background";
            _quadRenderer.sortingOrder = -5;
        }

        private void LateUpdate()
        {
            if (Person == null || Person.Limbs == null || Person.Limbs.Length == 0 || _quadRenderer == null)
                return;

            // Центрируем квад ауры по торсу (MiddleBody / UpperBody)
            Transform rootLimb = Person.Limbs[0].transform;
            Vector3 centerPos = rootLimb.position + (Vector3)VerticalOffset;
            _auraQuadObj.transform.position = new Vector3(centerPos.x, centerPos.y, 0.05f);
            _auraQuadObj.transform.rotation = Quaternion.identity;

            // Переводим мировые позиции сегментов рэгдолла в UV-пространство квада [0..1]
            int count = Mathf.Min(Person.Limbs.Length, 10);
            for (int i = 0; i < count; i++)
            {
                LimbBehaviour limb = Person.Limbs[i];
                if (limb == null || limb.Collider == null) continue;

                Bounds b = limb.Collider.bounds;
                Vector3 up = limb.transform.up * (b.extents.y * 0.75f);
                Vector2 startUV = WorldToQuadUV(limb.transform.position - up, centerPos);
                Vector2 endUV = WorldToQuadUV(limb.transform.position + up, centerPos);

                _limbCapsules[i] = new Vector4(startUV.x, startUV.y, endUV.x, endUV.y);
                _limbRadii[i] = Mathf.Clamp(b.extents.x / QuadSize.x, 0.025f, 0.09f);
            }

            _quadRenderer.GetPropertyBlock(_propBlock);
            _propBlock.SetInt(UseLimbCapsulesId, 1);
            _propBlock.SetVectorArray(LimbCapsulesId, _limbCapsules);
            _propBlock.SetFloatArray(LimbRadiiId, _limbRadii);
            _quadRenderer.SetPropertyBlock(_propBlock);
        }

        private Vector2 WorldToQuadUV(Vector3 worldPos, Vector3 quadCenter)
        {
            float u = (worldPos.x - quadCenter.x) / QuadSize.x + 0.5f;
            float v = (worldPos.y - quadCenter.y) / QuadSize.y + 0.5f;
            return new Vector2(u, v);
        }

        private void OnDestroy()
        {
            if (_auraQuadObj != null)
                Destroy(_auraQuadObj);
        }
    }
}
