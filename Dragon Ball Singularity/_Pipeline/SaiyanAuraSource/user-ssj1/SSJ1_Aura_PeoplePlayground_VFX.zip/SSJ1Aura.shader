Shader "PeoplePlayground/VFX/SSJ1Aura"
{
    Properties
    {
        [PerRendererData] _MainTex ("Sprite Texture", 2D) = "white" {}
        _Color ("Tint", Color) = (1,1,1,1)

        [Header(SSJ1 Aura Colors (Toei 1989 Palette))]
        [HDR] _CoreColor ("Inner Core Color (White-Hot)", Color) = (1.0, 0.99, 0.85, 1.0)
        [HDR] _MidColor ("Middle Flame Color (SSJ Gold)", Color) = (1.0, 0.88, 0.18, 1.0)
        [HDR] _OuterColor ("Outer Corona Color (Warm Amber)", Color) = (0.95, 0.58, 0.05, 1.0)
        [HDR] _RimColor ("Character Rim Light Color", Color) = (1.0, 0.96, 0.65, 1.0)

        [Header(Flame Dynamics (60 FPS Procedural))]
        _FlameSpeed ("Upward Flow Speed", Range(0.5, 8.0)) = 3.2
        _PulseSpeed ("Ki Pulse Frequency", Range(0.0, 15.0)) = 6.5
        _PulseAmount ("Ki Pulse Amplitude", Range(0.0, 0.35)) = 0.12
        _Turbulence ("Flame Turbulence & Detail", Range(0.5, 4.0)) = 2.1
        _FlameScale ("Flame Tongue Scale", Range(1.0, 10.0)) = 4.2

        [Header(Envelope and Cel Styling)]
        _AuraWidth ("Aura Expansion Width", Range(0.05, 0.6)) = 0.28
        _VerticalStretch ("Upward Flame Taper", Range(0.5, 3.0)) = 1.65
        _CelSteps ("Anime Cel Softness (0 = Cel, 1 = Smooth)", Range(0.02, 0.5)) = 0.14
        _OuterBloom ("Outer Ambient Glow Intensity", Range(0.0, 2.0)) = 0.85
        _RimIntensity ("Sprite Rim Light Intensity", Range(0.0, 2.0)) = 1.15
    }

    SubShader
    {
        Tags
        {
            "Queue" = "Transparent"
            "IgnoreProjector" = "True"
            "RenderType" = "Transparent"
            "PreviewType" = "Plane"
            "CanUseSpriteAtlas" = "True"
        }

        Cull Off
        Lighting Off
        ZWrite Off
        // Premultiplied-style additive-alpha blend so the aura both covers behind
        // and emits intense golden bloom in Unity 2D (People Playground)
        Blend One OneMinusSrcAlpha

        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma target 3.0
            #include "UnityCG.cginc"

            struct appdata_t
            {
                float4 vertex   : POSITION;
                float4 color    : COLOR;
                float2 texcoord : TEXCOORD0;
            };

            struct v2f
            {
                float4 vertex   : SV_POSITION;
                fixed4 color    : COLOR;
                float2 uv       : TEXCOORD0;
                float3 worldPos : TEXCOORD1;
            };

            sampler2D _MainTex;
            float4 _MainTex_TexelSize;
            fixed4 _Color;

            float4 _CoreColor;
            float4 _MidColor;
            float4 _OuterColor;
            float4 _RimColor;

            float _FlameSpeed;
            float _PulseSpeed;
            float _PulseAmount;
            float _Turbulence;
            float _FlameScale;
            float _AuraWidth;
            float _VerticalStretch;
            float _CelSteps;
            float _OuterBloom;
            float _RimIntensity;

            // Optional Limb Capsule Buffer passed from C# (10 ragdoll segments in local quad space)
            // xy = startA, zw = endB; _LimbRadii[i] = limb thickness
            uniform float4 _LimbCapsules[10];
            uniform float _LimbRadii[10];
            uniform int _UseLimbCapsules;

            v2f vert(appdata_t IN)
            {
                v2f OUT;
                OUT.vertex = UnityObjectToClipPos(IN.vertex);
                OUT.uv = IN.texcoord;
                OUT.worldPos = mul(unity_ObjectToWorld, IN.vertex).xyz;
                OUT.color = IN.color * _Color;
                return OUT;
            }

            // --- Procedural 2D Hash & Gradient Noise (Zero Texture Lookups, 60+ FPS) ---
            float2 hash22(float2 p)
            {
                p = float2(dot(p, float2(127.1, 311.7)), dot(p, float2(269.5, 183.3)));
                return -1.0 + 2.0 * frac(sin(p) * 43758.5453123);
            }

            float noise2D(float2 p)
            {
                float2 i = floor(p);
                float2 f = frac(p);
                float2 u = f * f * (3.0 - 2.0 * f);

                return lerp(
                    lerp(dot(hash22(i + float2(0.0, 0.0)), f - float2(0.0, 0.0)),
                         dot(hash22(i + float2(1.0, 0.0)), f - float2(1.0, 0.0)), u.x),
                    lerp(dot(hash22(i + float2(0.0, 1.0)), f - float2(0.0, 1.0)),
                         dot(hash22(i + float2(1.0, 1.0)), f - float2(1.0, 1.0)), u.x),
                    u.y);
            }

            // Ridged Anime Flame FBM (creates sharp upward-licking DBZ flame tongues)
            float animeFlameFBM(float2 p, float t)
            {
                float value = 0.0;
                float amp = 0.55;
                float2 shift = float2(100.0, 100.0);
                float2x2 rot = float2x2(0.80, 0.60, -0.60, 0.80);

                for (int i = 0; i < 4; i++)
                {
                    // Scroll each octave upward faster at higher frequencies
                    float2 flow = float2(0.0, -t * (1.0 + i * 0.45));
                    float n = noise2D(p + flow);
                    // Ridge shaping for pointed anime fire tips
                    float ridge = 1.0 - abs(n);
                    ridge = ridge * ridge;
                    value += amp * lerp(n * 0.5 + 0.5, ridge, 0.72);
                    p = mul(rot, p) * 2.05 + shift;
                    amp *= 0.5;
                }
                return value;
            }

            // Signed Distance to a 2D Line Segment (for People Playground Ragdoll Limbs)
            float sdCapsule(float2 p, float2 a, float2 b, float r)
            {
                float2 pa = p - a, ba = b - a;
                float h = saturate(dot(pa, ba) / max(dot(ba, ba), 0.0001));
                return length(pa - ba * h) - r;
            }

            // Smooth minimum to blend ragdoll limb fields into a unified body aura
            float smin(float a, float b, float k)
            {
                float h = max(k - abs(a - b), 0.0) / k;
                return min(a, b) - h * h * k * 0.25;
            }

            // Compute distance field from either C# Limb Capsules or Sprite Alpha Dilation
            float computeBodyDistance(float2 uv, out float spriteAlpha)
            {
                fixed4 tex = tex2D(_MainTex, uv);
                spriteAlpha = tex.a;

                if (_UseLimbCapsules > 0)
                {
                    float d = 10.0;
                    [unroll]
                    for (int i = 0; i < 10; i++)
                    {
                        float2 a = _LimbCapsules[i].xy;
                        float2 b = _LimbCapsules[i].zw;
                        float r = _LimbRadii[i];
                        float segD = sdCapsule(uv, a, b, r);
                        d = smin(d, segD, 0.045);
                    }
                    return d;
                }

                // Fallback: Multi-ring radial alpha distance estimation from _MainTex
                if (spriteAlpha > 0.5)
                    return -0.02;

                float minDist = 1.0;
                const int DIRS = 12;
                const int RINGS = 4;
                for (int r = 1; r <= RINGS; r++)
                {
                    float rad = (float(r) / RINGS) * _AuraWidth;
                    for (int a = 0; a < DIRS; a++)
                    {
                        float ang = (float(a) / DIRS) * 6.2831853;
                        float2 offset = float2(cos(ang), sin(ang) * 0.75) * rad;
                        float sampleA = tex2D(_MainTex, uv + offset).a;
                        if (sampleA > 0.2)
                        {
                            minDist = min(minDist, rad);
                        }
                    }
                }
                return minDist;
            }

            fixed4 frag(v2f IN) : SV_Target
            {
                float t = _Time.y * _FlameSpeed;
                float2 uv = IN.uv;

                // 1. Evaluate signed distance to the character silhouette
                float spriteAlpha;
                // Slightly compress UV vertically downward so aura rises higher above the head
                float2 fieldUV = uv;
                fieldUV.y -= max(0.0, uv.y - 0.35) * 0.14 * _VerticalStretch;

                float dist = computeBodyDistance(fieldUV, spriteAlpha);

                // 2. High-frequency Ki surge pulsation (classic 1989 Toei vibration)
                float pulse = sin(_Time.y * _PulseSpeed - max(0.0, dist) * 18.0) * _PulseAmount;
                float microVib = sin(_Time.y * 42.0 + uv.y * 30.0) * 0.004;

                // 3. Domain-warped coordinates for upward-licking anime flame tongues
                float2 flameUV = (uv - 0.5) * float2(_FlameScale * 1.35, _FlameScale / _VerticalStretch);
                // Inward pinch as flames rise toward the top of the character
                flameUV.x *= 1.0 + saturate(uv.y - 0.2) * 0.55;

                float warp = noise2D(flameUV * 1.4 + float2(0.0, -t * 1.3));
                flameUV.x += warp * 0.32 * _Turbulence;
                flameUV.y += abs(warp) * 0.18;

                float fbm = animeFlameFBM(flameUV * _Turbulence, t);
                float detailFbm = animeFlameFBM(flameUV * (_Turbulence * 2.1) + 13.7, t * 1.45);

                // 4. Normalized distance from body surface into the aura envelope
                float effectiveWidth = _AuraWidth * (1.0 + pulse + saturate(uv.y - 0.15) * 0.35);
                float normDist = max(0.0, dist + microVib) / max(effectiveWidth, 0.001);

                // Combine distance falloff with turbulent flame ridges
                float flameField = (1.0 - normDist) + (fbm - 0.45) * 0.58 + (detailFbm - 0.5) * 0.22;

                // 5. Three-tier Toei 1989 Super Saiyan Aura Layers:
                //    - Core: blinding white-yellow inner silhouette sheath
                //    - Mid: intense golden anime flame tongues
                //    - Outer: soft warm amber corona + atmospheric ground/air bloom
                float s = _CelSteps;
                float coreMask  = smoothstep(0.76 - s * 0.5, 0.76 + s * 0.5, flameField) * smoothstep(0.45, 0.0, normDist);
                float midMask   = smoothstep(0.42 - s,       0.42 + s,       flameField) * smoothstep(1.35, 0.15, normDist);
                float outerMask = smoothstep(0.14 - s * 1.4, 0.14 + s * 1.4, flameField) * smoothstep(1.85, 0.0, normDist);

                // Continuous ambient bloom around the entire character (like the 1989 movie glow)
                float ambientGlow = exp(-max(0.0, dist) / (effectiveWidth * 0.95)) * _OuterBloom;
                ambientGlow *= (0.82 + 0.18 * fbm);

                // Compose aura color layers
                float3 auraRGB = _OuterColor.rgb * (outerMask * 0.75 + ambientGlow * 0.85);
                auraRGB = lerp(auraRGB, _MidColor.rgb, saturate(midMask + ambientGlow * 0.35));
                auraRGB = lerp(auraRGB, _CoreColor.rgb, saturate(coreMask * 1.15));

                // Internal upward energy streaks inside the golden aura
                float streaks = smoothstep(0.62, 0.88, detailFbm) * midMask * 0.45;
                auraRGB += _CoreColor.rgb * streaks;

                float auraAlpha = saturate(max(outerMask * 0.92, ambientGlow * 0.75) + midMask * 0.5 + coreMask);

                // 6. Composite with character sprite + Golden Rim Lighting on the body
                fixed4 charCol = tex2D(_MainTex, uv) * IN.color;
                if (charCol.a > 0.01)
                {
                    // Inner rim factor based on proximity to silhouette edge
                    float rim = saturate(1.0 - (-dist / 0.045));
                    rim = pow(rim, 1.8) * (0.75 + 0.25 * detailFbm) * _RimIntensity;

                    float3 litChar = lerp(charCol.rgb, _RimColor.rgb, saturate(rim * 0.65));
                    litChar += _CoreColor.rgb * (rim * 0.35);

                    return fixed4(litChar * charCol.a, charCol.a);
                }

                // Premultiplied output for luminous additive-alpha hybrid glow
                return fixed4(auraRGB * auraAlpha, auraAlpha * 0.88);
            }
            ENDCG
        }
    }
}
