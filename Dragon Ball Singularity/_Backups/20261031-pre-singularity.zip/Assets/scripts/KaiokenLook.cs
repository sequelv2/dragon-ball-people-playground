using UnityEngine;

namespace DBPU
{
    // Standard Kaioken body tint. Base form gets the classic red flush; over a transformation
    // (SSJ / Blue) the flush is lighter and hair keeps its own colour, so Blue hair stays blue.
    public static class KaiokenLook
    {
        public static void ApplyBodyTint(PersonBehaviour person, float multiplier)
        {
            if (!person || person.Limbs == null) return;
            var ki = person.GetComponent<KiSystem>();
            bool layered = ki && CinematicAssets.KeepsInnerAura(ki.CurrentForm);
            float m = Mathf.Max(1f, multiplier);
            float body = layered ? Mathf.Clamp(.9f - m / 300f, .72f, .9f) : Mathf.Clamp(.8f - m / 100f, .45f, .8f);
            float hair = layered ? Mathf.Clamp(.96f - m / 600f, .88f, .96f) : body;
            foreach (var limb in person.Limbs)
            {
                if (!limb) continue;
                foreach (var sr in limb.GetComponentsInChildren<SpriteRenderer>(true))
                {
                    if (!sr || sr.name.StartsWith("DBPU")) continue;
                    float g = IsHair(sr.transform, limb.transform) ? hair : body;
                    sr.color = new Color(1f, g, g, sr.color.a);
                }
            }
        }
        static bool IsHair(Transform node, Transform limb)
        {
            for (; node != null; node = node.parent)
            {
                if (node.name.ToLowerInvariant().Contains("hair")) return true;
                if (node == limb) break;
            }
            return false;
        }
    }
}
